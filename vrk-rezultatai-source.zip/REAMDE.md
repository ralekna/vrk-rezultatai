This extension adds a table sorters to tables in website https://www.vrk.lt

## Building

No building required - all files are included.

## Updating dependencies

Run `npm install`

Copy from `node_modules/jquery/dist/jquery.min.js` to `libs/js/jquery.min.js`
Copy from `node_modules/tablesorter/dist/js/jquery.tablesorter.combined.min.js` to `libs/js/jquery.tablesorter.combined.min.js`
Copy from `node_modules/tablesorter/dist\css/theme.default.min.css` to `libs/css/theme.default.min.css`